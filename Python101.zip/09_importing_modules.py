# Python 101 code Ch 9 Importing modules
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# a) Import random and use randint
import random

# Note that we call the randint method
# (1,6) means choosing a number between
# 1 and 6
diceRoll=random.randint(1,6)
print("You rolled",diceRoll)

"""
# b) Import just randint
from random import randint #Should be 1st line

# Note that we can call randint()
# as a function now
diceRoll=randint(1,6)
print("You rolled",diceRoll)



# c) Using choice()
import random         #Should be 1st line

names=["Tom","Mary","Dave","Anna"]
winner = random.choice(names)
print("Winner is",winner)


# d) importing "as"
# rename the function we are importing as an alias
import matplotlib.pyplot as plt   #Should be 1st line

subjects = ["Maths", "English", "Irish", "Comp Sci"]
scores = [75, 68, 82, 90]

# If we didn't have the "as plt" above, we'd have
# to write
# matplotlib.pyplot.bar(subjects, scores)  #much longer
plt.bar(subjects, scores)                # much handier
plt.xlabel("Subject")
plt.ylabel("Score")
plt.title("Exam Scores")

plt.show()
"""