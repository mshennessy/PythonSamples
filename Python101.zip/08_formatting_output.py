# Python 101 code Ch 8 Formatting Output
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document


# a) basic print with end =
print("Hello")
print("there")
# or on one line
print("Hello", end=" ")
print("there")

for i in range(5):
    print("Hello", end="*")

"""
# b) using sep =
print("Tom","Mary","Dave","Anna")
print("Tom","Mary","Dave","Anna", sep="*")

# A nicer version of the box in Ch 3 using
# "sep=" and a for loop instead of repeating
# the print()
# You can also use maths for formatting
print("+"*22)
for i in range(5):
    print("+"," "*20,"+",sep="")  
print("+"*22)

# c) Escape characters
# newline and tab
print("Hello \n\nthere")
print("Hello \t\t\t\t there")

# making quotes appear in the output
#                       V escape character on "
print("Shakespeare said \"Shall I compare thee to a summer's day\"")

# d) Formatting columns
subjects=["Maths","PE","Geography"]
grades=[87,68,51]
# Show subject & grade
print("Messy")
for i in range(len(subjects)):
    print(subjects[i],grades[i])
# Neater output using .ljust()
# Choose a max column with (or calculate
# it from your data)
print("\nNeater")
width=10  # Wide enough for my data
# print column headings
print("Subjects".ljust(width),"Grade")
for i in range(len(subjects)):
    print(subjects[i].ljust(width),grades[i])

# e) f strings
name = "Tom"
age = 17
print(name, "is", age, "years old")
# or alternative formatting - don't use this
# until your Python skills have improved
# or possibly ever :)
print(f"{name} is {age} years old")
"""
