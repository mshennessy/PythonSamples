# Python 101 code Ch 7 - More lists and strings
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document
"""
# a) Similarities between lists and strings
# indexing
name="Murphy"
cities=["Dublin","Cork","Galway"]
print(name[0])
print(cities[0])

#slicing
print(name[2:5])
print(cities[1:])

# ordering
myList=[1,2,3]
myString="abc"
if myList == [3,2,1]:
    print("List order doesn't matter")
else:
    print("List order does matter")

if myString == "cba":
    print("String order doesn't matter")
else:
    print("String order does matter")

# methods
myStr = "Teacher"
# Python ref : string.lower()
print(myStr.lower()) # replace "string" with my string name
myList = [1,2,3]
# Python ref : list.append()
myList.append(4) # replace "list" with my list name

# using len()
print("Length of", name, "is", len(name))
print("Length of", cities, "is", len(cities))
# using max/min 
print(max(name),min(name)) # Note that alphabetically M < m
print(max(cities),min(cities)) # works alphabetically

# can use "in"
if "M" in name:
    print("Contains M")
if "Cork" in cities:
    print("Cork is in cities list")

# iterated with a for loop
for letter in name:
    print(letter)
for city in cities:
    print(city)

# concatenation (with +)
name= "Tom "+name
towns=["Athlone","Kildare"]
places=cities+towns
print(name)
print(places)

# repetition
print("+"*20)
longName=name*10
print(longName)
print(cities*5)
print(cities)


# using methods without a variable
print("tom".upper())
print([1,2,3].append(4)) # This returns the
                         # value None but not
                         # an error

# b) Differences
# You can't alter a string
name="tom"
# Remove comment from the next line to see the error
#name[0]="T" # gives an error because strings are fixed
# To alter the string we have to create a new
# string or overwrite
newName=name.replace("t","T") # would replace all "t"s
print(newName)
# Even better to use .capitalize() method (not
# in reference guide but very handy)
newName=name.capitalize()
print(newName)

# do methods alter the string?
name.upper()
print(name) # unchanged
cities.append("Kilkenny")
print(cities)

# c) list() and str() built-in functions
# using str()

name="Tom"
year=2006
userName=name+str(year)
print("Username:", userName)

# using list()
# change "abc" to ["a","b","c"]
name="Tom"
nameList=list(name)
print("name as a list:", nameList)
"""
# Converting a list to a string
myList=["a","b","c"]
print("using str():",str(myList))
# .join() can be applied to any string
# ie any string variable or an actual string
# In this case, we join the elements of the
# list using an empty string ''
print("using ''.join()",''.join(myList))
# Demo of what .join() does if the string
# isn't empty
print("using 'x'.join()",'x'.join(myList))
    
    