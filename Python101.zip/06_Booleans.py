# Python 101 code Ch 6 Booleans
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# a) Creating a boolean variable
# create a boolean
keepGoing=True
while keepGoing: # As long as boolean is True
    yesOrNo=input("Keep going? Y/N")
    if yesOrNo == 'N':
        keepGoing=False
print("You ended the while loop!")
"""
# b)
a = False
if a == True:
    print("a is true")
else:
    print("a is false")
# This is neater
if a:
    print("a is true")
else:
    print("a is false")

# Warning code
a = "Hello"
b = 35
c = -1
d = 0
if a:
    print(a, "is true")
if b:
    print(b, "is true")
if c:
    print(c, "is true") 
if d:
    print(d, "is true")
else:
    print(d, "is false")



# create a boolean
keepGoing=True
# Use it to control a while loop
while keepGoing: # As long as boolean is True
    yesOrNo=input("Keep going? Y/N")
    # Now stop if they type N or n
    # notice that the variable is repeated
    # Try replacing if statement with the line below
    # if yesOrNo == "N" or "n": # doesn't work
    if yesOrNo == 'N' or yesOrNo == 'n': # works
        keepGoing=False
print("You ended the while loop!")


# c)
#lists

cities=["Dublin","Cork","Galway"]
print(cities)
newCity="Kilkenny"
if newCity not in cities:
    cities.append(newCity)
print(cities)

#strings
name="Sam"
if "x" not in name:
    print("No 'x' in",name)
    
#combining elements
if name.isalpha() and len(name) >=3:
    print("Fully alphabetic letters in",name)
    print("At least 3 letters in",name)
else:
    print("Some non-alphabetic characters in",name)
"""
