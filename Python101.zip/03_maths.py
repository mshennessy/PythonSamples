# Python 101 code Ch 3 - Maths
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document



# a) Types of numbers
# We get the user to input 6 values
num1=input("Enter num 1 :")
num2=input("Enter num 1 :")
# Convert these to integers
# Note the nested functions
num3=int(input("Enter num 1 :"))
num4=int(input("Enter num 1 :"))
# Convert these to floats
num5=float(input("Enter num 1 :"))
num6=float(input("Enter num 1 :"))

print("Adding numbers - strings :",num1+num2)
print("Adding numbers - integers :",num3+num4)
print("Adding numbers - floats :",num5+num6)

"""
# Demo of how division results in a float
# even if the values divide evenly
x = 10
y = 5
z = x / y # Ans should be 2 but it's 2.0
print(type(z),z)



# b) Doing maths
# Using Operators
a=10
b=3
print("a + b = ",a+b)
print("a - b = ",a-b)
print("a * b = ",a*b)
print("a / b = ",a/b)
print("a ** b = ",a**b, "(this is",a,"to the power of",b,")")
print("a % b = ",a%b, "(this is the remainder when",a,"is divided by",b,")")
print("a // b = ",a//b, "(this is how many times",b,"divides fully into",a,")")

# Use of modulo %
a = 7
if a%2 == 0: # no remainder when we divide by 2
             # so a is even
    print("Even")
else:        # there is a remainder so a is odd
    print("Odd")


# c) Assignment operators
# Using Assignment operators
a = 6
a = a + 1  # Adds one to a
a += 1     # Adds one to a

c = 5
d = 6
c *= 6   # Multiply c by d and store result in c
print("c is ",c, "and d is",d)

# d) Other uses of maths
# You can also use maths for formatting
print("+"*22)
print("+"," "*18,"+") # print() adds a 
print("+"," "*18,"+") # space between items
print("+"*22)
  
name="Tommy"+" "+"Murphy"
#print(name)
  """