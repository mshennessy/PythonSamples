#Python 101 Ch 11: Read/Write Files
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# This demo comes with the test text file 11_file_to_read.txt

# a) opening a file for reading
print("Using a read()")
myRFile=open("./11_file_to_read.txt",'r')

# b) Options for reading f.read(n)
# Read the entire file into one string
contents = myRFile.read()
print(contents)

# Read 12 characters from the file 
contents = myRFile.read(12)
print(contents)
# Now read another 5 characters from the file 
contents = myRFile.read(8)
print(contents)

# ... or the whole file (note that it continues from previous read)
print(myRFile.read())
#Always close your file. We will reopen and start again
myRFile.close()
"""
# c) using readline()
print("Using a readline()")
myRFile=open("./11_file_to_read.txt",'r')
# You can also read a file, line by line
line1 = myRFile.readline()
line2 = myRFile.readline()
print(line1)
print(line2)
myRFile.close()

# ... or read all lines at once
print("Using a readlines()")
myRFile=open("./11_file_to_read.txt",'r')
# Or read all lines into a list - note readlines (plural)
filedump = myRFile.readlines()
print(type(filedump), filedump)
# Close the file

myRFile.close()

print("Using a for loop with the file object")
# Another way to read from a file
myRFile=open("./11_file_to_read.txt",'r')
for myLine in myRFile:
    # I use end='' in the next line as each line contains \n
    print(type(myLine), myLine, end='')
myRFile.close()
print("\n")

# e) writing to a file
myWFile=open("./11_writefile.txt",'w')
myWFile.write("First line of my text file!\n")
myWFile.write("Second line of my text file!\n")
myWFile.close()
# If we open this file for writing again, it will overwrite
# so we open for "append"

# f) appending (adding to an existing file)
# Now open the written file for appending and add a line
myAFile=open("./11_writefile.txt",'a')
myAFile.write("Third line of my text file!\n")
myAFile.close()

# g) reading line by line in a for loop
# I call my file object fLoop here to show that I am iterating
# through the file
fLoop = open("11_file_to_read.txt", "r")

for line in fLoop:
    print(line.strip())  # Try without strip()
                         # You get an extra newline

fLoop.close()

# h) with open() otion
# This is not in the ref guide, but it is a handy way to
# open a file without needing to close it.
with open("./11_file_to_read.txt", "r") as myFile:
    fileContent = myFile.read()
    print(fileContent)

# i) Handling CSV files
# When using csv files, don't use the normal file read options
import csv   # import is 1st line of code

with open("11_csvsample.csv", "r") as fCSV:
    reader = csv.reader(fCSV)

    for row in reader:
        print(row)

with open("11_outputCSV.csv", "w", newline="") as fCSV:
    writer = csv.writer(fCSV)
    writer.writerow(["Subject", "%"])
    writer.writerow(["Maths", 65])
    writer.writerow(["Computer Science", 95])
    writer.writerow(["Biology", 82])

# j) using pandas
# Using the pandas option
# This is what we'll use in our ALTs
import pandas as pd  # import is 1st line of code

df = pd.read_csv("11_outputCSV.csv")
#print(df)

print(df["Subject"])    # prints the Name column
print(df.loc[2])        # row by label/index
"""
    