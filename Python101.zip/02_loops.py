# Python 101 code Ch 2 loops
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# In a world without loops
print(0)
print(1)
print(2)
print(3)

# Alternative to 4 separate prints above
for i in range(4):
    print(i)
"""  
# The for loop
for i in range(1,30,7):
    print(i)


# The while loop
counter=0
while counter < 3:
    print("Still repeating",counter)
    counter = counter + 1
     
    
# A while loop that uses user input to stop
ans = "Yes"
while ans == "Yes":
    print("OK")
    ans = input("Do you want to keep going")
 """   
    
