# Python 101 code Ch 5 - Lists
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# a,b) Defining a list
# Initialising an empty list - first item
# in the list section of the reference guide
shopping=[]
queue=[]
# You can also define a list with elements in it
# This one is a list of strings
classList=["Aaron","Niall","Fergal"]
# ... or a list of single characters (still strings)
vowels=['A','E','I','O','U']
# You can have lists that are numbers
primes=[2,3,5,7,11,13]
# or floats
costs=[2.99,3.50,4.99,0.99]
# or a mixture of all these
randomStuff=["word",3,'c',7.22]

# c) Indexing into a list
# Change an element in a list
costs[1]=3.99
print(costs)
# Retrieve a range of items
print(primes[1:4])
# Last number of elements in a list
print(primes[3:])

"""
# d) - Length of a list
print("costs before:",costs)
for i in range(len(costs)):  # range function is
                             # len(costs) instead
                             # of a fixed number
    costs[i]+=1
print("costs after:",costs)

# To check if the list length is even, check the
# remainder (using modulo %) when you divide by 2
if len(costs) % 2 == 0:
    print("List length is even")
else:
    print("List length is odd")



# e) Adding values to a list
print("Before:",classList)
classList.append("Tom")
print("After .append():",classList)
classList.insert(2,"Frank")
print("After .insert():",classList)


# f) Removing items from a list
# Example of bad code
# This code fails because as soon as we remove
# an item in the list, the list is shorter
# than len(myList) in the for loop.
myList=[2,3,6,8,10]
for i in range(len(myList)):
    if myList[i] % 2 != 0: # if value is odd
        oddNum= myList.pop(i)
        print("Removed",oddNum)
print(myList)

# Good code examples of removing items
print("Before:",classList)
if "Fergal" in classList: # Don't attempt to remove
                          # and item that isn't in list
    classList.remove("Fergal")
print("After .remove():",classList)
# Now remove last item in list
removedName=classList.pop()
print("After .pop():",classList)
print(removedName,"was removed")


# g) Looping through a list
print("Costs before :",costs)
# First type of looping through a list
for price in costs: # "price" takes the value of
                    # each item in the list
    print("old price :", price)
    price +=1       # the price variable is
                    # increased by 1
    print("new price :", price)
#But the costs list hasn't changed
print("Costs after :",costs)


# Looping through a list with indexing
print("Before :",costs)
for i in range(len(costs)):
    print(i) # prints current index 0,1,2...
    print(costs[i]) # prints the item at that index
    costs[i]=round(costs[i]) # rounds each item
                    # and saves it back in the list
print("After :",costs)
"""

