# Python 101 code Ch 4 - Strings
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# All of the following are valid strings
firstName="Tom"
surname="O'Reilly"  # Note - you couldn't use single quotes here
address="12 Main Road,Dublin 21,D21A8Y6"
emptyString=""
gender='M'          # Note convention is to use single quotes
                    # for single characters, but both work
age="17"


# a) Indexing in strings
greeting = "Hello"
print(greeting[0])    # print 1st char
print(greeting[3])    # print 4th char
print(greeting[-1])   # Print last char
print(greeting[1:3])  # Print range

"""
# b) Concatenating strings
firstName="Mary"
surname="Murphy"
age=25
fullName=firstName+surname
print("Concatenated:",fullName)
fullName=firstName+" "+surname
print("Concatenated:",fullName)
# Note that we have to make the numeric age
# into a string so that we can concatenate it
fullNameAge=firstName+surname+str(age)
print("Concatenated:",fullNameAge)



# c) String methods
# Demo of string method
name="tom"
name.upper() # call the upper() method on this string
print(name)  # name hasn't changed
newName=name.upper()  # save updated name in new variable
print(newName)  # New variable contains the uppercase version of name

# d) Changing the look of a string
# Demo of string methods
city="Dublin"
capCity=city.upper()
lowCity=city.lower()
print(city,capCity,lowCity)

print("There is/are", city.count("b"),"bs in",city)

# e) Checking the type of content in a string
a="Hello"
b="123"
c="not_all_alpha"
print(a,"alpha ?",a.isalpha())
print(b,"digit ?",b.isdigit())
print(c,"alpha numeric?",c.isalnum())
"""
