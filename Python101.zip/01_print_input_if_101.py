# Python 101 code Ch 1 print() input() if else
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# This is a comment
"""
This is also a comment
"""

# a) Simple print function
print("Welcome to the Python Greeting Program!")

# More complex, set a variable to the next message
message = "This program will ask you a few questions."
# ... an print the variable
print(message)

# Printing multiple items (more later)
print("Message:",message)

# 1b assignment
a=10  # This is how we initialise a variable and
      # set its value to 10
b=5   # Same for b, sets value to 5
a=b   # a is overwritten with new value
b=b+1 # now change b (add 1 to it)
print("a is",a,"and b is",b)

# 1c The input() function
# When we don't care what the user types in ....
input("Press Enter to continue...")
# When we are trying to get data from the user
# Note the structure - we have to store what they type in in a variable

name = input("What is your name? ")
#age = input("How old are you? ")

# Note that the second input will be a number, but in the line above
# it is stored as a string. If we want to treat it as a number, we
# have to convert it to an integer. Note the structure below and remember it.
age = int(input("How old are you? "))

"""
# Now we make a compound print. Note that there is a comma inside the
# string in the next line and a black comma before the variable name
# The black comma is separating the stuff you are sending to the print function
# The green comma is just punctuation to make the output look better
print("Nice to meet you,", name)
# This time we are sending the print function 3 comma separated things
print("You are", age, "years old.")

#1d conditionals
# Now we look at conditionals. Note the indentation here
if age < 13:
    print("You're a pre-teen.") 
elif age < 18:
    print("You're a teenager.")
elif age < 30:
    print("You're a young adult.")
else:
    print("You're an adult.")

# Checking two values are equal
if age == 16:
    print("Sweet sixteen!!")

if age != 16:
    print("Just a normal age")

#print("Thanks for using the Python Greeting Program!")
"""