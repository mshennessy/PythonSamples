# Python 101 code Ch 10 def functions
# Ms Hennessy CUS
# Read through the accompanying chapter as
# you try out this code.
# Some blocks of code are commented out using
# """    """ and you should 'uncomment' them
# when you get to that section in the document

# a) Where to define functions
import random
# AFTER imports and BEFORE the main code
# define the function
def showNumber():
    value=random.randint(1,6)
    print("Your random number is", value)

# call the function showNumber()
showNumber()
"""
# b) Passing a value to a function
import random
# AFTER imports and BEFORE the main code
# define the function
def showNumber(maxIn):
    value=random.randint(1,maxIn)
    print("Your random number is", value)

maxValue=int(input("Choose random number between 1 and what value? "))
# call the function showNumber() and pass in the value input by user
showNumber(maxValue)


# Example to show scope
def demoParameters(param):
    # Reassign value of param
    # but remember this is a black box
    # so effectively, this "param"
    # is a different variable from the
    # one defined outside the function
    param = 10
    print("Inside function:",param)
# Initialise variable called param
param = 5
demoParameters(param)
print("After function:",param)

# c) returning a value
import random
# define the function, with parameter "maxIn"
def getNumber(maxIn):
    # Use the value passed in to the function
    value=random.randint(1,maxIn)
    # return the random number 
    return value

maxValue=int(input("Choose random number between 1 and what value? "))
# randValue will be returned from the new function getNumber()
randValue=getNumber(maxValue)
print("Your random number is", randValue)

#d) Multiple values in and out
import random
# Pass in 2 values - order is
#  important
def getPosition(maxX,maxY):
    newX=random.randint(1,maxX)
    newY=random.randint(1,maxY)
    # return 2 values - order is
    # important
    return newX, newY

# Get 2 return values - again order
# is important
x,y = getPosition(240,140)
print(x,y)
"""